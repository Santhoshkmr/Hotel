//SelectBOX


function customformComponents (){
                var thisSelected = [];
				
				$('.btns').each(function(){
					//thisinput=$(this).html();
					//$(this).html('<span>'+thisinput+'</span>');
				});
				
                $('.custSelect').each(function(){
                                disable=$(this).attr('disabled');
                                multi=$(this).attr('multiple');
                                thisDiv=document.createElement('div');
                                                if($(this).attr('id')){
                                                thisDiv.id=$(this).attr('id');
                                                }
                                thisUL=document.createElement('ul');
                                $(thisDiv).append(thisUL).addClass("custSelDiv").addClass($(this).attr('class')).removeClass('custSelect');
                                $(thisDiv).prepend('<div class="custSelText"></div>');
                                $(this).after('<div class="selParent"></div>');
								$(this).next('div').append(thisDiv);
                                                $(this).find('option').each(function(){
                                                                thisCheck=document.createElement('input');
                                                                thisCheck.type="checkbox";
                                                                thisCheck.className="chk";
                                                                                if(disable=='disabled'){
                                                                                                $(thisDiv).addClass('disabled');
                                                                                                thisCheck.disabled='disabled';
                                                                                }
                                                                                
                                                                                
                                                                thisLBL=document.createElement('label');
                                                                thisLI=document.createElement('li');
                                                                $(thisLBL).text($(this).text());
                                                                $(thisLI).attr('name',$(this).attr('value'));
                                                                $(thisLI).attr('onClick',$(this).attr('onClick'));
                                                                if($(this).attr('selected')=='selected'){
                                                                $(thisLI).addClass('selected');     
                                                                }
                                                                
                                                //$(thisLBL).appendTo(thisLI);
                                                if(multi=="multiple"){
                                                                $(thisDiv).addClass('custSelDivMulti');
                                                                $(thisLI).append(thisCheck,thisLBL);
                                                }

                                                else{
                                                                $(thisLI).append(thisLBL);
                                                }
                                                $(thisLI).appendTo(thisUL);
                                
                                });
                                
                                $(this).hide();
                                //defining default Value
                                if(multi!="multiple"){
                                //$(thisUL).find('li:first').addClass('selected');
                                $(thisDiv).find('.custSelText').append('<span>'+$(thisUL).find('.selected').text()+'</span>');
                                }
                                else{
                                //lbltext=$(thisDiv).closest('.frmCol').find('.lbl').clone();
                                //$(lbltext).find('span').remove();
                                //$(thisDiv).find('.custSelText').append('<span>'+$(lbltext).text()+'</span>');
                                $(thisDiv).find('.custSelText').append('<span></span>');
                                }
                                //defining default value
                                
                                $(this).removeAttr('id');
                                                if($(this).closest('.accumulator').length>=1){
                                                $(thisUL).addClass("optSelect");
                                                //$(thisUL).find('li:first').removeClass('selected');
                                                $(thisUL).after("<div class='addremoveOpt'><div class='addOpt'>&raquo;</div><div class='removeOpt'>&laquo;</div></div>");
                                                $(thisUL).clone().appendTo(thisDiv).addClass("optSelected").removeClass("optSelect").html('');
                                }
                
                });
                //multi select header click
                $('.custSelText').live('click',function(e){
					$('.contentPanel').removeClass('topIndex');
    $('.tabContentPanel').removeClass('topIndex');
                                if($(this).parent().hasClass('disabled')==false){
                                                $('.custSelDiv').removeClass('selectOpen');
                                                $('.custSelText').next().hide();
                                                $(this).parent().addClass('selectOpen');
												thismargin=parseInt($(this).parent().css("margin-right"));
												$(this).closest('.selParent').width($(this).parent().width()+thismargin);
												$(this).closest('.selParent').height($(this).parent().height());
                                                $(this).next().show();
                                                //$(this).next().width('');
												if($(this).next().height()>=200){
												$(this).next().width("");
                                                $(this).next().width($(this).next().width()+30);
												}
												$(this).next().css( "max-height","200px" );
                                                //$(this).next().css( "overflow","auto" );
                                                $(this).closest('.contentPanel').addClass('topIndex');
                                                $(this).closest('.tabContentPanel').addClass('topIndex');
                                                e.stopPropagation();
                                }
                });
                //end multi select header click
                
                $('.selectOpen custSelText').live('click',function(){
                $(this).parent().removeClass('selectOpen');
                $(this).next().hide();
                });
                //multi select options
                $('.custSelDiv li').live('click',function(e){

                                                if($(this).closest('.custSelDiv').hasClass('disabled')==false){
                                                thisSelected = [];
                                                $(this).closest('.custSelDiv').find('.custSelText').text('');
                                                
                                                if($(this).closest('.custSelDiv').hasClass('custSelDivMulti')){
													$(this).addClass('selected');
													$(this).find('input').attr('checked','checked');
													
													if($(this).text()=='Select All'){
														$(this).closest('.custSelDiv').find('input').attr('checked','checked');
														$(this).closest('.custSelDiv').find('li').addClass('selected');
													}
                                                }
                                                else{
													
												if($(this).closest('.custSelDiv').hasClass('callshowhide')){
													$(this).closest('.custSelDiv').find('li').each(function(){
																	$('#'+$(this).attr('name')).hide();
													});
													$('#'+$(this).attr('name')).show();
													$('#'+$(this).attr('name')).removeClass('showhideDetail');
                                				}
												else if($(this).closest('.custSelDiv').hasClass('callFile')){
													
													window.location =$(this).attr('name');
													
												}
													
													
                                                  $(this).parent().hide();
                                                  $(this).parent().prev().removeClass('selectOpen');
                                                  $(this).closest('.custSelDiv').find('li').removeClass('selected');
                                                  $(this).addClass('selected');
                                                }
                                                $(this).parent().find('li.selected').each(function(){
																if($(this).text()!='Select All'){
                                                                thisSelected.push($(this).text());
																}
                                                });
                                                $(this).closest('.custSelDiv').find('.custSelText').append('<span>'+thisSelected.join(", ")+'</span>');
                                                $(this).closest('.custSelDiv').find('.custSelText span').attr('title',thisSelected.join(", "));
                                                e.stopPropagation();
                               					 }
											
                                
                                
                });
                $('.custSelDivMulti .selected').live('click',function(){
					
					if($(this).text()=='Select All'){
						$(this).closest('.custSelDiv').find('input').removeAttr('checked');
						$(this).closest('.custSelDiv').find('li').removeClass('selected');
						$(this).closest('.custSelDiv').find('.custSelText span').text('');
						}
					
                           else{
							    thisSelected = [];
                                $(this).removeClass('selected');
                                $(this).find('input').removeAttr('checked');
                                
                                $(this).closest('.custSelDiv').find('.custSelText span').text('');
                                $(this).parent().find('li.selected').each(function(){
                                if($(this).text()!='Select All'){
                                 thisSelected.push($(this).text());
								}
                                });
                                if(thisSelected.length!=0){
                                $(this).closest('.custSelDiv').find('.custSelText span').text(thisSelected.join(","));
                                $(this).closest('.custSelDiv').find('.custSelText span').attr('title',thisSelected.join(", "));
                                }
                                else{
                                $(this).closest('.custSelDiv').find('.custSelText span').text('');
                                }
						   }
                });

//SelectBOX	

	///auto complete
		var availableTags = [
			"ActionScript",
			"AppleScript",
			"Asp",
			"BASIC",
			"C",
			"C++",
			"Clojure",
			"COBOL",
			"ColdFusion",
			"Erlang",
			"Fortran",
			"Groovy",
			"Haskell",
			"Java",
			"JavaScript",
			"Lisp",
			"Perl",
			"PHP",
			"Python",
			"Ruby",
			"Scala",
			"Scheme"
		];
		$( ".tags" ).autocomplete({	source: availableTags});
		//auto complete
		
		//add/remove
		  $('.addOpt').live('click',function() {
		  return !$(this).closest('.accumulator').find('.optSelect .selected').click().remove().appendTo($(this).closest('.accumulator').find('.optSelected'));
		 });
		 $('.removeOpt').live('click',function() {
		  return !$(this).closest('.accumulator').find('.optSelected .selected').click().remove().appendTo($(this).closest('.accumulator').find('.optSelect'));
		 });
		//add/rimove

	$(document).click(function(){
		$(".custSelDiv:not('.accumulator .custSelDiv')").each(function(){
		$(this).find('.custSelText').parent().removeClass("selectOpen");
		$(this).find('ul').hide();
		$('.contentPanel').removeClass('topIndex');
    $('.tabContentPanel').removeClass('topIndex');

		});
	});
	
}
