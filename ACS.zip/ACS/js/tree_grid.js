 $(document).ready(function () {

            'use strict';

            var topicjson={

                "response": [

                       {

                           "id": "1",

                           "menuoption": "Administration and Maintenance",
                           level:"0", parent:"", isLeaf:false, expanded:true, loaded:true

                       },

                       {

                           "id": "2",

                           "menuoption": "User Creation",

                           level:"1", parent:"1", isLeaf:false, expanded:true, loaded:true

                       },
					   {

                           "id": "21",

                           "menuoption": "Bank User"
						   ,"add": ""
						   ,"modify": ""
						   ,"delete": ""
						   ,"view": ""
						   ,"authorize": ""
						   ,"fileupload": ""
						   ,"release": ""
						   ,"generate": ""
						   ,"import": ""
						   ,"viewimport": ""
						   ,"selectall": "",
                           level:"2", parent:"2", isLeaf:true, expanded:false, loaded:true

                       },
					   {

                           "id": "22",

                           "menuoption": "Customer User"
						   ,"add": ""
						   ,"modify": ""
						   ,"delete": ""
						   ,"view": ""
						   ,"authorize": ""
						   ,"fileupload": ""
						   ,"release": ""
						   ,"generate": ""
						   ,"import": ""
						   ,"viewimport": ""
						   ,"selectall": "",
                           level:"2", parent:"2", isLeaf:true, expanded:true, loaded:true

                       },
					   {

                           "id": "3",

                           "menuoption": "Transaction",
                           level:"0", parent:"", isLeaf:false, expanded:true, loaded:true

                       },

                       {

                           "id": "4",

                           "menuoption": "Payments",

                           level:"1", parent:"3", isLeaf:false, expanded:true, loaded:true

                       },
					   {

                           "id": "32",

                           "menuoption": "Own Account Transfer"
						   ,"add": ""
						   ,"modify": ""
						   ,"delete": ""
						   ,"view": ""
						   ,"authorize": ""
						   ,"fileupload": ""
						   ,"release": ""
						   ,"generate": ""
						   ,"import": ""
						   ,"viewimport": ""
						   ,"selectall": "",
                           level:"2", parent:"4", isLeaf:true, expanded:false, loaded:true

                       },
					   {

                           "id": "33",

                           "menuoption": "Third Party Transfer"
						   ,"add": ""
						   ,"modify": ""
						   ,"delete": ""
						   ,"view": ""
						   ,"authorize": ""
						   ,"fileupload": ""
						   ,"release": ""
						   ,"generate": ""
						   ,"import": ""
						   ,"viewimport": ""
						   ,"selectall": "",
                           level:"2", parent:"4", isLeaf:true, expanded:false, loaded:true

                       },
					    {

                           "id": "34",

                           "menuoption": "Multi Banking Transfer"
						   ,"add": ""
						   ,"modify": ""
						   ,"delete": ""
						   ,"view": ""
						   ,"authorize": ""
						   ,"fileupload": ""
						   ,"release": ""
						   ,"generate": ""
						   ,"import": ""
						   ,"viewimport": ""
						   ,"selectall": "",
                           level:"2", parent:"4", isLeaf:true, expanded:false, loaded:true

                       },
					   {

                           "id": "35",

                           "menuoption": "Bank to Bank Transfer"
						   ,"add": ""
						   ,"modify": ""
						   ,"delete": ""
						   ,"view": ""
						   ,"authorize": ""
						   ,"fileupload": ""
						   ,"release": ""
						   ,"generate": ""
						   ,"import": ""
						   ,"viewimport": ""
						   ,"selectall": "",
                           level:"2", parent:"4", isLeaf:true, expanded:false, loaded:true

                       },
					   {

                           "id": "5",

                           "menuoption": "Account Services"
						   ,"add": ""
						   ,"modify": ""
						   ,"delete": ""
						   ,"view": ""
						   ,"authorize": ""
						   ,"fileupload": ""
						   ,"release": ""
						   ,"generate": ""
						   ,"import": ""
						   ,"viewimport": ""
						   ,"selectall": "",
                           level:"2", parent:"3", isLeaf:false, expanded:false, loaded:true

                       },
					    {

                           "id": "6",

                           "menuoption": "Fixed Deposit"
						   ,"add": ""
						   ,"modify": ""
						   ,"delete": ""
						   ,"view": ""
						   ,"authorize": ""
						   ,"fileupload": ""
						   ,"release": ""
						   ,"generate": ""
						   ,"import": ""
						   ,"viewimport": ""
						   ,"selectall": "",
                           level:"2", parent:"3", isLeaf:false, expanded:false, loaded:true

                       }

					   
                   ]

                },

                grid;



            $('<table id="list2"></table>').appendTo('#topics');

			function cboxFormatter(cellvalue, options, rowObject)
			{
				return '<input type="checkbox">';
			}

            grid = jQuery("#list2");

            grid.jqGrid({

                datastr: topicjson,

                datatype: "jsonstring",

                height: "auto",

                loadui: "disable",

       colNames: ["Menu Option","Add","Modify","Delete","View","Authorize","File Upload","Release","Generate","Import","View Import","Select All"],

                colModel: [
 {name: "menuoption", width:200, resizable: false,sortable:false,index: 'FeatureId'},
                    {name: "add",width:50,sortable:false,formatter:cboxFormatter},
					{name: "modify",width:50,sortable:false,formatter:cboxFormatter},
					{name: "delete",width:50,sortable:false,formatter:cboxFormatter},
					{name: "view",width:50,sortable:false,formatter:cboxFormatter},
					{name: "authorize",width:50,sortable:false,formatter:cboxFormatter},
					{name: "fileupload",width:50,sortable:false,formatter:cboxFormatter},
					{name: "release",width:50,sortable:false,formatter:cboxFormatter},
					{name: "generate",width:50,sortable:false,formatter:cboxFormatter},
					{name: "import",width:50,sortable:false,formatter:cboxFormatter},
					{name: "viewimport",width:50,sortable:false,formatter:cboxFormatter},
					{name: "selectall",width:50,sortable:false,formatter:cboxFormatter}
                ],

                treeGrid: true,

                treeGridModel: "adjacency",

                caption: "Access Rights",

                ExpandColumn: "menuoption",

                autowidth: true,

                //width: 180,

                rowNum: 10000,
				onSelectRow: function(id,status){
                  var rowData = jQuery(this).getRowData(id); 
                  var ch =  jQuery(this).find('#'+id+' input[type=checkbox]').attr('checked');
                  if(ch) {
                            jQuery(this).find('#'+id+' input[type=checkbox]').attr('checked',false);
                  } else {
                            jQuery(this).find('#'+id+' input[type=checkbox]').attr('checked',true);                       
                  }

                  rowChecked=1;
                  currentrow=id;
                  },

                //ExpandColClick: true,

               // treeIcons: {leaf:'ui-icon-document-b'},

                jsonReader: {

                    repeatitems: false,

                    root: "response"

                }

            });

        });