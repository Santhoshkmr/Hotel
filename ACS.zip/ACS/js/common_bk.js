var delrecord;
$().ready(function(){
	
	//tabindex
	
	var tabindex = 10005;

				$('.addTabIndex').each(function(index){
							$(this).find('img').attr('tabindex',tabindex+index);
							$(this).addClass('opened');
				});
				
								
				$('.addTabIndex.closed').live('keypress',function(e) {
						if(e.keyCode==13){
							$(this).click();
						}
				});
				
				$('.addTabIndex.closed').live('click',function() {
					//alert("123");
					$(this).closest('table').find('.rf-cst').css( "display","table-row-group" );
					$(this).removeClass('closed');
					$(this).addClass('opened');
					//alert("Clicked ---> panel opened");					
				});				
					
				$('.addTabIndex.opened').live('keypress',function(e) {
					if(e.keyCode==13){	
						$(this).click();
					}
				});
				
				$('.addTabIndex.opened').live('click',function() {
						
						$(this).closest('table').find('.rf-cst').css( "display","none" );
						$(this).addClass('closed');
						$(this).removeClass('opened');
						//alert("Clicked ---> panel closed");					
				});				
	//end Tab Index
		
		
		$('.popBg').hide();

	
	$('.popClose').click(function(){
		$(this).closest('.popBg').hide();
		$(this).closest('.popupWrapper').hide();
	});
	$('.messClose').click(function(){
		$(this).closest('.messBoxWrap').hide();
		$(this).closest('.blockDetails').hide();
	});
	
	$('.popCloseBtn').click(function(){
    $(this).closest('.popBg').hide();
    $(this).closest('.popupWrapper').hide();
  });
    
    $('.popCloseBtn input').click(function(){
    $(this).closest('.popBg').hide();
    $(this).closest('.popupWrapper').hide();
  });
	
	//accordian
	
	///activating first accordian panel
	$('.accordianPanel').each(function(){
		$(this).find('.accordianHeading:first').addClass('active');
		$(this).find('.accordianContent:first').show();
	});
	
	$('.accordianHeading').live('click',function(){
		if($(this).hasClass('active')){
		$(this).next().hide();
		$(this).removeClass('active');
		}
		else{
		//$(this).closest('.accordianPanel').find('.accordianContent').hide();
		//$(this).closest('.accordianPanel').find('.accordianHeading').removeClass('active');
		$(this).addClass('active');
		$(this).next().show();
		$(window).scrollTop($(this).offset().top-160);
		}
	});
	
	//table Accordian
	$('.teBtn').live('click',function(){
		$(this).closest('thead').addClass('active');
		$(this).closest('thead').next('tbody').find('tr').show();
		$(this).addClass('accActive');
	});
	
	$('.accActive').live('click',function(){
		$(this).closest('thead').removeClass('active');
		$(this).closest('thead').next('tbody').find('tr').hide();
		$(this).removeClass('accActive');
	});
	//end table Accordian
	
	
	//tabsections
	//activating fist tab as default selection
	$('.tabPanel').each(function(){
    if($(this).find('.tabHeading li.active').length==0){
    $(this).find('.tabHeading li:first').addClass('active');
    $(this).find('.tabContent:first').show();
    }
    else{
    $(this).find('.tabContent').eq($(this).find('.tabHeading li.active').index()).show();
    }
  });

	$('.tabHeading li').live('click',function(){
		$(this).closest('.tabPanel').find('.tabContent').hide();
		$(this).parent().find('li').removeClass('active');
		$(this).addClass('active');
		$(this).closest('.tabPanel').find('.tabHeading').each(function(){
			currentTab=$(this).find('.active a').attr('name');
			$('#'+currentTab).show();
		});
	});
	// Less details top moving code
	
	$('.lessDetails').live('click', function(){
		$(this).addClass('top');
		//$(this).next().show();
		$(window).scrollTop(0);
		//$('html').animate({scrollTop:-160},'slow');
		//$(window).scrollTop($(this).offset().top -10);
	});
	
//expand/collapse
                $('.expand').live('click',function(){
                                $(this).closest('h2').next('.accordianPanel').find('.accordianContent').show();
                                $(this).closest('h2').next('.accordianPanel').find('.accordianContent').find('.arrowclose').click();
                                $(this).closest('h2').next('.accordianPanel').find('.accordianHeading').addClass('active');
                                $(this).text('Collapse All');
                                $(this).addClass('collapse');
                                $(this).removeClass('expand');
                });
                $('.collapse').live('click',function(){
                                
                                $(this).closest('h2').next('.accordianPanel').find('.accordianContent').hide();
                                $(this).closest('h2').next('.accordianPanel').find('.accordianContent').find('.arrowopen').click();
                                $(this).closest('h2').next('.accordianPanel').find('.accordianHeading').removeClass('active');
                                $(this).text('Expand All');
                                $(this).removeClass('collapse');
                                $(this).addClass('expand');
                });

	
	//table Expand Collapse
		$('.tblexpand').live('click',function(){
		$(this).parent().parent().find('.teBtn').not('.accActive').click();
		$(this).text('Collapse All');
		$(this).addClass('tblcollapse');
		$(this).removeClass('tblexpand');
	});
	
		$('.tblcollapse').live('click',function(){
		$(this).parent().parent().find('.accActive').click();
		$(this).text('Expand All');
		$(this).addClass('tblexpand');
		$(this).removeClass('tblcollapse');
	});
	
	$('.dropdown').not('#user .dropdown').mouseover(function(e){
		e.stopPropagation();
		$('.dropList').hide();
		$(this).find('.dropList').show();
	});
	$('#user .dropdown').click(function(e){
		e.stopPropagation();
		$('.dropList').hide();
		if($(this).find('.dropList').hasClass('disp')){
		$(this).find('.dropList').hide();
		$(this).find('.dropList').removeClass('disp');
		}
		else{
			$(this).find('.dropList').show();
			$(this).find('.dropList').addClass('disp');
		}
	});
	
	$('.dropdown').not('#user .dropdown').mouseout(function(e){
		e.stopPropagation();
		//$('.dropList').hide();
		$(this).find('.dropList').hide();
	});
	$('.dropList li').click(function(e){
		e.stopPropagation();
		$('.dropList').hide().removeClass('disp');
	});
	
	$(document).click(function(){
	$('.dropList').hide().removeClass('disp');
	$(".custSelDiv ul").hide();
	});
	
	//search buttons
	$('.advSearch').live('click',function(){
		$(this).closest('.btnRow').parent().find('.advSearchPaenl').show();
		$(this).addClass('basSearch').removeClass('advSearch').text('Basic Search');;
	});
	$('.basSearch').live('click',function(){
		$(this).closest('.btnRow').parent().find('.advSearchPaenl').hide();
		$(this).addClass('advSearch').removeClass('basSearch').text('Advanced Search');;
	});
	
	//moreDetails
	$('.moreDetails').live('click',function(){
		$(this).closest('.mainTopInfo').find('.moreDetailsview').show();
		$(this).text('Less Details').addClass('lessDetails').removeClass('moreDetails');
	});
	$('.lessDetails').live('click',function(){
		$(this).closest('.mainTopInfo').find('.moreDetailsview').hide();
		$(this).text('More Details').addClass('moreDetails').removeClass('lessDetails');
	});
	
	
	//panel Open and Close
	
$('.panOpen').live('click',function(){
	$(this).closest('.contentPanel').find('.frmContent').hide();
	$(this).closest('.headText').height(36);
	$(this).addClass('panClose');
	$(this).removeClass('panOpen');
});

$('.panClose').live('click',function(){
	$(this).closest('.contentPanel').find('.frmContent').show();
	$(this).addClass('panOpen');
	$(this).closest('.headText').height(40);
	$(this).removeClass('panClose');
});

//leftNavigation

$('#leftsubNav li:not(.subNav)').live('click',function(){
	$('#leftsubNav li').removeClass('active');
	$(this).addClass('active');
});

$('#leftsubNav li.subNav').live('click',function(){
	$(this).addClass('subActive');
});
$('#leftsubNav li').live('click',function(e){
	e.stopPropagation();
});
$('#leftsubNav li.subActive').live('click',function(){
	$(this).removeClass('subActive');
});

$('#leftNav li').live('click',function(){
	$(this).addClass('active');
});
$('#leftNav li li').live('click',function(e){
	e.stopPropagation();
	$('#leftNav li li').removeClass('active');
	$(this).addClass('active');
});
$('#leftNav li.active').live('click',function(){
	$(this).removeClass('active');
});

	//datepicker//
	$( ".datepicker" ).datepicker({
			showOn: "button",
			buttonImage: "../../images/calendar.gif",
			buttonImageOnly: true,
			currentText: 'Today',
			buttonText: 'Calendar',
			dateFormat: 'dd/mm/yy',
			changeMonth: true,
			changeYear: true,
			//gotoCurrent: true,
			showButtonPanel: true,
		});
		$(".datepicker").datepicker("setDate", new Date());
		
	//datePicker
	
	//datepicker Disabled//
	$( ".datepickerDisabled" ).datepicker({
			showOn: "button",
			buttonImage: "../images/calendar.gif",
			buttonImageOnly: true,
			disabled: true,
			currentText: 'Now',
			buttonText: 'Calendar',
			dateFormat: 'dd/mm/yy',
			gotoCurrent: true
		});
		$(".datepickerDisabled").datepicker("setDate", new Date());
	//datePicker Disabled
	
	
  //select All for non table content
                $('.selAll').live('click',function(){
                                $(this).parent().next().find('.selRow').attr('checked','checked');
                                //$(this).closest('table').find('.selRow').click();
                                $(this).addClass('deselAll').removeClass('selAll');
                });
                $('.deselAll').live('click',function(){
                                $(this).parent().next().find('.selRow').removeAttr('checked');
                                //$(this).closest('table').find('.selRow').click();
                                $(this).addClass('selAll').removeClass('deselAll');
                });
                $('.selRow').live('click',function(){
                                $(this).closest('.scrollContent').prev().find('.deselAll').removeAttr('checked');
                                ///$(this).closest('table').find('tr').removeClass('selected');
                                $(this).closest('.scrollContent').prev().find('.deselAll').addClass('selAll').removeClass('deselAll');
                });
                //end select All for non table content
	//table Select options
	$('.selAllpage .selAll').live('click',function(){
		$(this).closest('.scrollContent').find('.gridTbl').find('.selAll').click();
	});
		$('.selAllpage .deselAll').live('click',function(){
		$(this).closest('.scrollContent').find('.gridTbl').find('.deselAll').click();
	});
	$('.gridTbl .selAll').live('click',function(){
		$(this).closest('table').find('.selRow').attr('checked','checked');
		$(this).closest('table').find('tr').not('.subHeader').addClass('selected');
		//$(this).closest('table').find('.selRow').click();
		$(this).addClass('deselAll').removeClass('selAll');
	});
	$('.gridTbl .deselAll').live('click',function(){
		$(this).closest('table').find('.selRow').removeAttr('checked');
		$(this).closest('table').find('tr').removeClass('selected');
		//$(this).closest('table').find('.selRow').click();
		$(this).addClass('selAll').removeClass('deselAll');
		
		///for select all pages check box
		$(this).closest('.scrollContent').find('.deselAll').click();
	});
	$('.gridTbl .selRow').live('click',function(){
		$(this).closest('table').find('.deselAll').removeAttr('checked');
		///$(this).closest('table').find('tr').removeClass('selected');
		$(this).closest('table').find('.deselAll').addClass('selAll').removeClass('deselAll');
		
		///for select all pages check box
		$(this).closest('.scrollContent').find('.deselAll').click();
	});
	// table row mouse hover effects
	$('.linkTbl tr').mouseover(function(){
		$(this).find('td:first').addClass('bdrL');
		$(this).find('td:last').addClass('bdrR');
	});
	$('.linkTbl tr').mouseout(function(){
		$(this).find('td:first').removeClass('bdrL');
		$(this).find('td:last').removeClass('bdrR');
	});
	
	//button span click
	$('.btn').click(function(){
		$(this).find('input').click();
	});
		$('.btns').click(function(){
		$(this).find('input').click();
	});
	$('.btn input').click(function(e){
		e.stopPropagation();
	});
		$('.btns input').click(function(e){
		e.stopPropagation();
	});
	$('.btnSec input').mousedown(function(){
		$(this).addClass('btnFocus');
	});
	$('.btnSec input').mouseup(function(){
		$(this).removeClass('btnFocus');
	});
	$('.btn input').mousedown(function(){
		$(this).addClass('btnFocus');
	});
	$('.btn input').mouseup(function(){
		$(this).removeClass('btnFocus');
	});
	$('.btnSecBig input').mousedown(function(){
		$(this).addClass('btnFocus');
	});
	$('.btnSecBig input').mouseup(function(){
		$(this).removeClass('btnFocus');
	});
	$('.btnPriblue input').mousedown(function(){
		$(this).addClass('btnFocus');
	});
	$('.btnPriblue input').mouseup(function(){
		$(this).removeClass('btnFocus');
	});
	
	
	///multiselectGrid
	$('.SelCol').live('click',function(){
		$(this).addClass('checked');
		tdnum=$(this).closest('td').index();
		$(this).closest('.tbody_parent').find('tr').each(function(){
		 $(this).find('td').eq(tdnum).find('input:not(.checked)').click().addClass('checked');
		})
		$(this).addClass('deSelCol');
		$(this).removeClass('SelCol');
	});
	$('.deSelCol').live('click',function(){
		$(this).removeClass('checked');
		tdnum=$(this).closest('td').index();
		$(this).closest('.tbody_parent').find('tr').each(function(){
		 $(this).find('td').eq(tdnum).find('.checked').click().removeClass('checked');
		})

		$(this).addClass('SelCol');
		$(this).removeClass('deSelCol');
		$(this).closest('.tbody_parent').find('.remRows').addClass('selRows').removeClass('checked').removeAttr("checked").removeClass('remRows');
		$(this).closest('.tbody_parent').find('.deSelColRow').addClass('SelColRow').removeAttr("checked").removeClass('deSelColRow');
	});
	
	$('.selRows').live('click',function(){
		$(this).addClass('checked');
		$(this).closest('tr').find('input:not(.checked)').click().addClass('checked');
		$(this).addClass('remRows');
		$(this).removeClass('selRows');
	});
	
	$('.remRows').live('click',function(){
		$(this).removeClass('checked');
		$(this).closest('tr').find('.checked').click().removeClass('checked');
		$(this).addClass('selRows');
		$(this).removeClass('remRows');
		$(this).closest('.tbody_parent').find('.deSelCol').addClass('SelCol').removeClass('checked').removeAttr("checked").removeClass('deSelCol');
		$(this).closest('.tbody_parent').find('.deSelColRow').addClass('SelColRow').removeAttr("checked").removeClass('deSelColRow');
	});
	
	
	$('.SelColRow').live('click',function(){
		$(this).closest('.tbody_parent').find('.selRows').click();
		$(this).closest('.tbody_parent').find('.SelCol').click();
		$(this).addClass('deSelColRow');
		$(this).removeClass('SelColRow');
	});
	
	$('.deSelColRow').live('click',function(){
		$(this).closest('.tbody_parent').find('.remRows').click();
		$(this).closest('.tbody_parent').find('.deSelCol').click();
		$(this).addClass('SelColRow');
		$(this).removeClass('deSelColRow');
	});
	
	$('.tbody_parent input').live('click',function(){
		if($(this).attr('checked')=='checked'){
		$(this).addClass('checked');
		}
		else{
		$(this).removeClass('checked');
		}
	});
	//end multiselect grid
	
		$('.recordDel').live('click',function(e){
			delrecord=this;
			showPop(this,'delconf');
			/*if($(this).closest('.showhideDetail').length==0){
			$(this).closest('.accordianHeading').hide().next().hide();
			}
			else{
				$(this).closest('.showhideDetail').hide();
			}*/
		    e.stopPropagation();
	});
	
	
});

function delconfpop(){
	//alert($(delrecord).html());
	if($(delrecord).closest('.showhideDetail').length==0){
	$(delrecord).closest('.accordianHeading').next().remove();
	$(delrecord).closest('.accordianHeading').remove();
	}
	else{
	$(delrecord).closest('.showhideDetail').hide();
	}
}

function showPop(thislocation,showThis){	
  $('.popBg').show();
  $('.popupWrapper').hide();
  $('#'+showThis).show();
 $('#'+showThis).offset({top: $('#headerBG').offset().top+210})
  $('.popBg').height($(document).height());
  $('.secpopBg').hide();
  //$(document).scrollTop($(thislocation).offset().top-160);
}
function showSecPop(showThis){
  $('.secpopBg').show();
  $('#'+showThis).show();
  $('.secpopBg').height($(document).height());
}
function showPopMsg(thislocation,thisMsg){
	$('#'+thisMsg).hide();
	$('#'+thisMsg).show();
	$('#'+thisMsg).offset({ top: $(thislocation).offset().top+20})
	//$('#'+thisMsg).css("top",$(thislocation).offset().top+20);
}
//function showContent(showThis){
	//alert("123");
	//$('#'+showThis).show();
//}
function showContent(showThis){
  $('#'+showThis).show();
}
function hideContent(hideThis){
  $('#'+hideThis).hide();
}
function windowLocation(thispage){
	window.location = thispage;
    return false;
}
function checkBank(){
if($('#bankName').val()=="First Gulf Bank"){
  window.location = "accountStatementFGB.html";
  } 
  else{
    window.location = "accountStatementNon-FGB.html";
  }
}
function showinfoMsg(thismsg){
$('#'+thismsg).fadeIn();
    setTimeout(function() {
        $('#'+thismsg).fadeOut();
      }, 2000 );

}




/*Item Selector*/
$(document).ready(function() {
var count = 2;
$('#attachMore').click(function(){
/*	for (var i = 1; i <= pageLimit; i++) {
             $('.fileattach').append('TESTING');
     }*/
	 $('#attached').each(function(){
		  $("#attached").append('<div><input type="checkbox" class="form-checkbox" name="device" /> <a href="#" class="form-cb-label-after">Attachment '+count+'</a>(<a href="#">View</a> &nbsp; <a href="javascript:void(0)" name="deleteAttach">Delete</a>)</div>')
		  count++;
	 })
})
	$('a[name="deleteAttach"]').live('click',function() {
    	$(this).parents("div:first").remove();
	});


/*Multi Level Checkbox Selection*/
// add multiple select / deselect functionality
/*$("#select_col_1").click(function () {
	  $('.case').attr('checked', this.checked);
});

$("#select_col_2").click(function () {
	  $('.col_02').attr('checked', this.checked);
});

$("#select_col_3").click(function () {
	  $('.col_03').attr('checked', this.checked);
});

$("#select_col_4").click(function () {
	  $('.col_04').attr('checked', this.checked);
});

$("#select_col_5").click(function () {
	  $('.col_05').attr('checked', this.checked);
});

$("#select_col_6").click(function () {
	  $('.col_06').attr('checked', this.checked);
});

$("#select_col_7").click(function () {
	  $('.col_07').attr('checked', this.checked);
});

$("#select_col_8").click(function () {
	  $('.col_08').attr('checked', this.checked);
});

$("#select_col_9").click(function () {
	  $('.col_09').attr('checked', this.checked);
});

$("#select_col_10").click(function () {
	  $('.col_10').attr('checked', this.checked);
});

$("#select_level_02_col_1").click(function () {
	  $('.level_02_case').attr('checked', this.checked);
});

$("#select_level_02_col_2").click(function () {
	  $('.col_02').attr('checked', this.checked);
});

$("#select_level_02_col_3").click(function () {
	  $('.col_03').attr('checked', this.checked);
});

$("#select_level_02_col_4").click(function () {
	  $('.col_04').attr('checked', this.checked);
});

$("#select_level_02_col_5").click(function () {
	  $('.col_05').attr('checked', this.checked);
});

$("#select_level_02_col_6").click(function () {
	  $('.col_06').attr('checked', this.checked);
});

$("#select_level_02_col_7").click(function () {
	  $('.col_07').attr('checked', this.checked);
});

$("#select_level_02_col_8").click(function () {
	  $('.col_08').attr('checked', this.checked);
});

$("#select_level_02_col_9").click(function () {
	  $('.col_09').attr('checked', this.checked);
});

$("#select_level_02_col_10").click(function () {
	  $('.col_10').attr('checked', this.checked);
});



// if all checkbox are selected, check the selectall checkbox
// and viceversa
/*$(".case").click(function(){

	if($(".case").length == $(".case:checked").length) {
		$("#select_col_1").attr("checked", "checked");
	} else {
		$("#select_col_1").removeAttr("checked");
	}

});*/

/*Multi Level Checkbox Selection*/
// add multiple select / deselect functionality
/*$("#select_trans_01").click(function () {
	  $('.trans_col_01').attr('checked', this.checked);
});

$("#select_trans_02").click(function () {
	  $('.trans_col_02').attr('checked', this.checked);
});

$("#select_trans_03").click(function () {
	  $('.trans_col_03').attr('checked', this.checked);
});

$("#select_trans_04").click(function () {
	  $('.trans_col_04').attr('checked', this.checked);
});

$("#select_trans_05").click(function () {
	  $('.trans_col_05').attr('checked', this.checked);
});

$("#select_trans_06").click(function () {
	  $('.trans_col_06').attr('checked', this.checked);
});

$("#select_trans_07").click(function () {
	  $('.trans_col_07').attr('checked', this.checked);
});

$("#select_trans_08").click(function () {
	  $('.trans_col_08').attr('checked', this.checked);
});

$("#select_trans_09").click(function () {
	  $('.trans_col_09').attr('checked', this.checked);
});

$("#select_trans_10").click(function () {
	  $('.trans_col_10').attr('checked', this.checked);
});


$("#select_pay_01").click(function () {
	  $('.pay_col_01').attr('checked', this.checked);
});

$("#select_pay_02").click(function () {
	  $('.pay_col_02').attr('checked', this.checked);
});

$("#select_pay_03").click(function () {
	  $('.pay_col_03').attr('checked', this.checked);
});

$("#select_pay_04").click(function () {
	  $('.pay_col_04').attr('checked', this.checked);
});

$("#select_pay_05").click(function () {
	  $('.pay_col_05').attr('checked', this.checked);
});

$("#select_pay_06").click(function () {
	  $('.pay_col_06').attr('checked', this.checked);
});

$("#select_pay_07").click(function () {
	  $('.pay_col_07').attr('checked', this.checked);
});

$("#select_pay_08").click(function () {
	  $('.pay_col_08').attr('checked', this.checked);
});

$("#select_pay_09").click(function () {
	  $('.pay_col_09').attr('checked', this.checked);
});

$("#select_pay_10").click(function () {
	  $('.pay_col_10').attr('checked', this.checked);
});*/
 $(document).ready(function() {
	 	 $('#freq_Id :radio[name=frequency] ').change(function(){
		 $('.showAns').hide();
		 $('#q1_'+$(this).val()).show();
	})
	 
/*	 $('#freq_Id :radio[name=frequency] ').change(function(){
		 $('ul.showAns').hide();
		 $('#q1_'+$(this).val()).show(100).html();
	})*/
		//Class 'contentContainer' refers to 'li' that has child with it.
        //By default the child ul of 'contentContainer' will be set to 'display:none'
            $("#treeMenu li").toggle(			
				  function() { // START FIRST CLICK FUNCTION
					  $(this).children('ul').slideDown()
					  if ($(this).hasClass('contentContainer')) {
						  $(this).removeClass('contentContainer').addClass('contentViewing');
					  }
				  }, // END FIRST CLICK FUNCTION
				  function() { // START SECOND CLICK FUNCTION
					  $(this).children('ul').slideUp()
					  if ($(this).hasClass('contentViewing')) {
						  $(this).removeClass('contentViewing').addClass('contentContainer');
					  }
						} // END SECOND CLICK FUNCTIOn
					); // END TOGGLE FUNCTION 
        }); // END DOCUMENT READY
/*Toggle Multilevel row with grid*/	

$('#admin').click(function(){
$('.admin_c').toggle();

if ($(this).css("display") == "block") {
	$('.admin_c').hide();
	}else{
		$('.admin_c').show()
		return false
	}

if ($(this).hasClass("arrowclose")) {
	$(this).removeClass("arrowclose").addClass("arrowopen");
	}else{
	$(this).removeClass("arrowopen").addClass("arrowclose");
	}
});

$('#user_Id').click(function(){
$('.user_c').toggle();
if ($(this).hasClass("arrowclose")) {
	$(this).removeClass("arrowclose").addClass("arrowopen");
	}else{
	$(this).removeClass("arrowopen").addClass("arrowclose");
	}
});

$('#trans_Id').click(function(){
$('.trans_c').toggle();
if ($(this).hasClass("arrowclose")) {
	$(this).removeClass("arrowclose").addClass("arrowopen");
	}else{
	$(this).removeClass("arrowopen").addClass("arrowclose");
	}

});

$('#Fixed_Dep').click(function(){
$('.Fixed_Dep').toggle();
if ($(this).hasClass("arrowclose")) {
	$(this).removeClass("arrowclose").addClass("arrowopen");
	$(this).closest('.tbody_parent3').find('.grid-group-hd_inactive').removeClass("grid-group-hd_inactive").addClass("grid-group-hd");
	}else{
	$(this).removeClass("arrowopen").addClass("arrowclose");
	$(this).closest('.tbody_parent3').find('.grid-group-hd').removeClass("grid-group-hd").addClass("grid-group-hd_inactive");
	}
});

$('#Fixed_Dep').addClass('arrowclose')
$('.Fixed_Dep').hide();
$('#AccSer').addClass('arrowclose')
$('.acc_ser').hide();
$('#AccSer').click(function(){
$('.acc_ser').toggle();
if ($(this).hasClass("arrowclose")) {
	$(this).removeClass("arrowclose").addClass("arrowopen");
	$(this).closest('.tbody_parent2').find('.grid-group-hd_inactive').removeClass("grid-group-hd_inactive").addClass("grid-group-hd");
	}else{
	$(this).removeClass("arrowopen").addClass("arrowclose");
	$(this).closest('.tbody_parent2').find('.grid-group-hd').removeClass("grid-group-hd").addClass("grid-group-hd_inactive");
	}
});

// added on May 24th 2012 
$('.tablesorter .arrowopen').each(function(event){
                $(this).removeClass("arrowopen").addClass("arrowclose");
                $(this).closest("tr").nextAll().hide();
                $('.tbody_head').next().find('tr').show();
                $('.tbody_head').next().find('.arrowclose').removeClass("arrowclose").addClass("arrowopen");
                $(this).closest('.tbody_parent').find('.grid-group-hd').removeClass("grid-group-hd").addClass("grid-group-hd_inactive");
                $('.tbody_head').next().find('.grid-group-hd_inactive').removeClass("grid-group-hd_inactive").addClass("grid-group-hd");
})

                

$('.tablesorter .arrowclose, .arrowopen').click(function(event){
event.stopPropagation();
var $target = $(event.target);
if ($(this).hasClass("arrowopen")) {
            $target.closest("tr").nextAll().hide();
                                    $(this).removeClass("arrowopen").addClass("arrowclose");
                                                $(this).closest('.tbody_parent').find('.grid-group-hd').removeClass("grid-group-hd").addClass("grid-group-hd_inactive");
       } else {
             $target.closest("tr").nextAll().show();
                                    $(this).removeClass("arrowclose").addClass("arrowopen");
                                                 $(this).closest('.tbody_parent').find('.grid-group-hd_inactive').removeClass("grid-group-hd_inactive").addClass("grid-group-hd");
                                                
 } 
 
 })


$('#pay_Id').click(function(){
$('.pay_c').toggle();
if ($(this).hasClass("arrowclose")) {
	$(this).removeClass("arrowclose").addClass("arrowopen");
	$(this).closest('.tbody_parent').find('.grid-group-hd_inactive').removeClass("grid-group-hd_inactive").addClass("grid-group-hd");
	}else{
	$(this).removeClass("arrowopen").addClass("arrowclose");
	$(this).closest('.tbody_parent').find('.grid-group-hd').removeClass("grid-group-hd").addClass("grid-group-hd_inactive");
	}
});

 //Moving selected item(s) to the select box provided on right
 $('.moveright').click(function() { 
	$(this).closest('.items_selector_container').find('.fromSelectBox option:selected').remove().appendTo($(this).closest('.items_selector_container').find('.toSelectBox'));
 });
 
 //Moving selected item(s) to the select box provided on left
 $('.moveleft').click(function() {
	$(this).closest('.items_selector_container').find('.toSelectBox option:selected').remove().appendTo($(this).closest('.items_selector_container').find('.fromSelectBox'));

 });



$('.accrodianlinkmenu li a').click(function(){
	
	$('.accrodianlinkmenu li a').removeClass('current');
	$(this).addClass('current')
		
})

});

//The function given below is to validate the select box, if none of the item(s) is selected then it alerts saying 'Please select atleast one option' if user selects an item then it returns true
function isSelected(thisObj){
 if (!$(thisObj+" option:selected").length){
 alert("Please select atleast one option");
 return 0;
 }
 return 1;
}

//The function given below is to validate the select box, if none of the item(s) where present in the select box provided then it alerts saying 'There are no options to select/move' if select box has more than one item it returns true

function noOptions(thisObj){
 if(!$(thisObj+" option").length){
 alert("There are no options to select/move");
 return 0;
 }
 return 1;
}

// added by selva 
